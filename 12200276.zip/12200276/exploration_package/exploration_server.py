# Import the ROS 2 Python library
import rclpy
# Import the necessary components for creating an Action Server
from rclpy.action import ActionServer
from rclpy.node import Node
# Import the custom Exploration action message
from custom_msgs.action import Exploration

# Create a class for the Exploration Action Server
class ExplorationServer(Node):
    def __init__(self):
        super().__init__('exploration_server')
        # Create an Action Server for the Exploration action
        self._action_server = ActionServer(
            self,
            Exploration,
            'exploration',
            self.execute_callback
        )

    # Define the execute callback function for the action server
    async def execute_callback(self, goal_handle):
        # Create feedback and result messages for the action
        feedback_msg = Exploration.Feedback()
        result_msg = Exploration.Result()

        self.get_logger().info('Exploration action received.')

        # Simulated exploration logic (replace with actual code)
        for percent_complete in range(0, 101, 10):
            feedback_msg.percent_complete = percent_complete
            goal_handle.publish_feedback(feedback_msg)
            self.get_logger().info(f'Exploration: {percent_complete}% complete.')
            await self._action_server.wait_for_goal(handle=goal_handle, timeout_sec=1.0)

        # Check if the goal was canceled or succeeded and update the result
        if goal_handle.is_cancel_requested:
            self.get_logger().info('Exploration canceled.')
            result_msg.result = Exploration.Result.CANCELED
            goal_handle.canceled()
        else:
            self.get_logger().info('Exploration completed.')
            result_msg.result = Exploration.Result.SUCCEEDED
            goal_handle.succeed(result_msg)

# Define the main function
def main(args=None):
    # Initialize the ROS 2 node
    rclpy.init(args=args)
    # Create an instance of the ExplorationServer class
    server = ExplorationServer()
    # Start the ROS 2 node
    rclpy.spin(server)

# Check if the script is the main module
if __name__ == '__main__':
    # Call the main function
    main()

