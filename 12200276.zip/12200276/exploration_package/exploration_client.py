# Import the ROS 2 Python library
import rclpy
# Import the necessary components for creating an Action Client
from rclpy.action import ActionClient
# Import the custom Exploration action message
from custom_msgs.action import Exploration
# Import the time library
import time

# Define the main function
def main(args=None):
    # Initialize the ROS 2 node
    rclpy.init(args=args)
    # Create an Action Client for the Exploration action
    client = ActionClient(Exploration, 'exploration')

    # Wait for the action server to become available
    while not client.wait_for_server(timeout_sec=1.0):
        print('Waiting for the server...')

    # Create an Exploration goal message
    goal_msg = Exploration.Goal()
    # Populate the goal message with exploration parameters (modify as needed)

    # Send the goal message to the action server
    goal_handle = client.send_goal_async(goal_msg)

    # Wait for the result
    result = None
    while rclpy.ok():
        result = goal_handle.result()
        if result:
            break

    # Check if the exploration goal was canceled or succeeded
    if result.result == Exploration.Result.CANCELED:
        print('Exploration goal was canceled.')
    else:
        print('Exploration goal was successfully completed.')

# Check if the script is the main module
if __name__ == '__main__':
    # Call the main function
    main()

